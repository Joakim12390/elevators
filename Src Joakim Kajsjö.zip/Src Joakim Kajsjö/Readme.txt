F�r att k�ra programmet:

mvn package

Default �r 6st hissar och 3st v�ningar
java -jar target\elevator-2017.12-SNAPSHOT.jar se.oneagency.elevator.numberofelevators=(antal hissar) se.oneagency.elevator.numberoffloors=(antal v�ningar)

Simulation
Default 5st hissar, 10st v�ningar och 22 hissresor(requests).

�ndra SpringbootTest variablarna eller requests variabeln f�r att modifiera simulationen.


Programmet loggar 4st event:
* N�r det tar emot ett giltigt request.
* N�r en hiss b�rjar �ka f�r att h�mta upp en person
* N�r en hiss h�mtar upp en person
* N�r en hiss sl�pper av en person

Ett request representerar att kalla p� en hiss och trycka p� en v�ning.

Hissarna fungerar som om det finns en knapp(inte upp/ner) f�r att kalla p� en hiss. Det tar 2 sec f�r hissarna att �ka mellan varje v�ning. B�st l�mpad f�r waiting floor �r den hiss som �r ledig och n�rmast. 


Framtida �ndringar:
Simulation:
L�gga till en random delay mellan requests.

Program:
* L�gga till s� man kan namnge v�ningar. ex -1, BV, 1
* Fixa s� att man kan kalla p� hiss utan att �ka n�gonstans. Om man �ndrar sig och vill ta trapporna, s� en timeout p� requests.
* Se att man kan plocka upp flera personer p� v�g upp/ner.
* Kunna ta bort/l�gga till en hiss (f�r underh�ll/reparationer).
* Fixa s� att det inte tar 0sec att kliva av och p� en hiss.



