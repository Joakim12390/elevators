package se.oneagency.codechallenge.elevator;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import se.oneagency.codechallenge.elevator.basic.ElevatorControllerService;
import se.oneagency.codechallenge.elevator.handler.ElevatorApplication;

/**
 * Boiler plate test class to get up and running with a test faster.
 *

 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = ElevatorApplication.class, properties = {"se.oneagency.elevator.numberofelevators=5", "se.oneagency.elevator.numberoffloors=10"})
public class IntegrationTest {
    
    @Autowired 
    private ElevatorControllerService elevatorCtrlservice;

    private ExecutorService executor;
    
    private int requests = 22;
    private Random random = new Random();
    private int numberOfFloors;
    private int numberOfElevators;
    
    @Test
    public void simulateAnElevatorShaft() {
        numberOfFloors = elevatorCtrlservice.getNumberOfFloors();
        numberOfElevators = elevatorCtrlservice.getNumberOfElevators();
        executor = elevatorCtrlservice.getExecutor();
        System.out.println("*** STARTING SIMULATION ***");
        System.out.println("number of Elevators: " +numberOfElevators);
        System.out.println("Number of floors: " +numberOfFloors +"\n");
        // Create random input at random intervals to ElevatorControllerService
        for(int i = 0; i < requests; i++) {
            
            int atfloor = random.nextInt(numberOfFloors);
            int tofloor = random.nextInt(numberOfFloors);
            elevatorCtrlservice.useElevator(atfloor, tofloor);
        }
        while (!elevatorCtrlservice.getRequests().isEmpty()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                
            }
        }
        executor.shutdown();
        try {
            executor.awaitTermination(1, TimeUnit.HOURS);
        } catch (InterruptedException ex) {
            Logger.getLogger(IntegrationTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Pending requests:" + elevatorCtrlservice.getRequests().size());
        System.out.println("*** END OF SIMULATION ***");
    }
}
