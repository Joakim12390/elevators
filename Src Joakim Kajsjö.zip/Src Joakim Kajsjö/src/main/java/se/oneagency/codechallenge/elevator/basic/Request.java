/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.oneagency.codechallenge.elevator.basic;

/**
 *
 * @author Joakim
 */
public class Request {
    private int id;
    private int atFloor;
    private int toFloor;
    
    public Request(int id, int atFloor, int toFloor) {
        this.id = id;
        this.atFloor = atFloor;
        this.toFloor = toFloor;
    }
    // Returns the floor the person is currently at, requesting an elevator.
    public int getAtFloor() {
        return atFloor;
    }
    // Returns the floor the person wants to take the elevator to.
    public int getToFloor() {
        return toFloor;
    }
    
    public int getId() {
        return id;
    }
    @Override
    public String toString() {
        return "Request{id:"+id+", starting floor:"+ atFloor+ " , end floor"+ toFloor+"}";
    }
}
