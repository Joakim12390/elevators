package se.oneagency.codechallenge.elevator.resources;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import se.oneagency.codechallenge.elevator.basic.ElevatorControllerService;
import se.oneagency.codechallenge.elevator.api.ElevatorsApi;

/**
 * Rest Resource.
 *
 */
@RestController
public final class ElevatorsApiController implements ElevatorsApi {

    @Autowired 
    private ElevatorControllerService controller;
    
    @Override
     public ResponseEntity<List> getAllElevators() {
        return new ResponseEntity<>(controller.getElevators(), HttpStatus.OK);
    }
     
     @RequestMapping(method=RequestMethod.POST,value = "/elevators/useElevator/")
    public ResponseEntity<Void> useElevator(@RequestParam(value="atfloor") String atFloor, @RequestParam(value="tofloor") String toFloor) {
        if(Integer.parseInt(atFloor) < 0 || Integer.parseInt(atFloor) > controller.getNumberOfFloors() ||
                Integer.parseInt(toFloor) < 0 || Integer.parseInt(toFloor) > controller.getNumberOfFloors()) {
            return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
        }
        controller.useElevator(Integer.parseInt(atFloor), Integer.parseInt(toFloor));
        return new ResponseEntity<Void>(HttpStatus.OK);
    }
}
