package se.oneagency.codechallenge.elevator.basic;
import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import se.oneagency.codechallenge.elevator.api.Elevator;
import se.oneagency.codechallenge.elevator.api.ElevatorController;
/**
 *
 * @author Joakim
 */
@Service
public class ElevatorControllerService implements ElevatorController{
    private int numberOfFloors;
    private int numberOfElevators;
    private int requestCounter = 0;
    
    private List<Elevator> elevators;
    private  List<Request> requests;
    private List<Elevator> availableElevators;
    
    private EventBus eventBus;
    
    private Logger logger = Logger.getLogger(ElevatorControllerService.class.getName());
    
    @Autowired
    private ExecutorService executor;
    
    public ElevatorControllerService(@Value("${se.oneagency.elevator.numberoffloors}") int numFloors, 
            @Value("${se.oneagency.elevator.numberofelevators}") int numElevators,
            EventBus eventBus) {
        
        this.eventBus = eventBus;
        this.eventBus.register(this);
        numberOfFloors = numFloors;
        numberOfElevators = numElevators;
        
        requests = new ArrayList();
        elevators = new ArrayList<>();
        for(int i = 0; i < numberOfElevators; i++) {
            elevators.add(new BasicElevator(i, this.eventBus));
        }
        availableElevators = elevators;
    }
    
    //Calling an elevator and then pressing a floor
    public void useElevator(int atFloor, int ToFloor) {
        Request request = new Request(requestCounter, atFloor, ToFloor);
        requestCounter++;
        requests.add(requests.size(), request);
        processRequest();
        logger.log(Level.INFO, "Added new request to pending requests. " + request.toString());
    }
    
    // Process the first request
    public synchronized void processRequest() {
        if(availableElevators.isEmpty() || requests.isEmpty()) {
            return;
        }
        Request request = requests.get(0);
        BasicElevator elevator = (BasicElevator)requestElevator(request.getAtFloor());
        elevator.takeRequest(request);
        executor.execute(elevator);
        availableElevators.remove(elevator);
        requests.remove(request);
    }
            
    @Override
    public Elevator requestElevator(int toFloor) {
        Elevator e = availableElevators.get(0);
        for(int i = 1; i < availableElevators.size(); i++) {
            if(Math.abs(availableElevators.get(i).currentFloor()- toFloor) < Math.abs(availableElevators.get(i-1).currentFloor() -toFloor)) {
                e = availableElevators.get(i);
            }
        }
        return e;
    }

    @Override
    public List<Elevator> getElevators() {
        return elevators;
    }

    @Subscribe
    public void handleReleaseEvent(Elevator event) {
        releaseElevator(event);
        processRequest();
    }
    @Override
    public synchronized void releaseElevator(Elevator elevator) {
        availableElevators.add(elevator);
    }
    
    public int getNumberOfFloors() {
        return numberOfFloors;
    }
    
    public int getNumberOfElevators() {
        return numberOfElevators;
    }
    
    public ExecutorService getExecutor(){
        return executor;
    }
    
    public List<Request> getRequests() {
        return requests;
    }
}
