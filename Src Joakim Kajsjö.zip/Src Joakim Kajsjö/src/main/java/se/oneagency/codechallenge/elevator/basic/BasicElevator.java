package se.oneagency.codechallenge.elevator.basic;

import com.google.common.eventbus.EventBus;
import java.util.logging.Level;
import java.util.logging.Logger;
import se.oneagency.codechallenge.elevator.api.Elevator;

/**
 *
 * @author Joakim
 */
public class BasicElevator implements Elevator, Runnable {
    private DirectionEnum direction;
    private int id;
    // All elevators starts standing still at groundfloor 
    private int currentFloor = 0;
    private boolean busy = false;
    // The floor the elevator is currently moving to
    private int addressedFloor = 0;
    // The floor that the person wants to go to
    private int endFloor = 0;
    
    private Request currentRequest;
    
    private String elevatorId;
    
    private EventBus eventBus;
    
    private Logger logger = Logger.getLogger(BasicElevator.class.getName());
    
    public BasicElevator(int elevatorID, EventBus eventBus) {
        id = elevatorID;
        this.eventBus = eventBus;
        direction = DirectionEnum.NONE;
        elevatorId = "Elevator id:" + id + " ";
    }
    
    public void run() {
        busy = true;
        
        logger.log(Level.INFO, elevatorId + "going to floor " + addressedFloor + ", " + currentRequest.toString());
        moveElevator(addressedFloor);
        
        logger.log(Level.INFO,elevatorId + "picked up person at floor:"+ currentFloor + " and is now going to floor:" + endFloor +", " + currentRequest.toString());
        moveElevator(endFloor);
        
        logger.log(Level.INFO,elevatorId + "Droped of person at floor:" + currentFloor +", " + currentRequest.toString());
        direction = direction.NONE;
        busy = false;
        // post available event
        eventBus.post(this);
    }
    
    public void takeRequest(Request request) {
        currentRequest = request;
        addressedFloor = currentRequest.getAtFloor();
        endFloor = currentRequest.getToFloor();
    }
    
    @Override
    public DirectionEnum getDirection() {
        return direction;
    }

    @Override
    public int getAddressedFloor() {
        return addressedFloor;
    }

    @Override
    public int getId() {
        return id;
    }

    /*
        moving the elevator 1 floor every 2 seconds, and when it reaches the end destination it declares availability. 
        It takes 2 seconds for a person to enter/leave the elevator.
    */
    @Override
    public void moveElevator(int toFloor) {
        if (currentFloor < toFloor) {
            direction = DirectionEnum.UP;
        } else if (currentFloor > toFloor){
            direction = DirectionEnum.DOWN;
        }
        while(currentFloor != toFloor) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                
            }
            switch (direction) {
                case UP: {
                    currentFloor++;
                    break;
                }
                case DOWN: {
                    currentFloor--;
                    break;
                }
            }
        }
    }

    @Override
    public boolean isBusy() {
        return busy;
    }

    @Override
    public int currentFloor() {
        return currentFloor;
    }
    
    @Override 
    public String toString() {
        return String.format(elevatorId + ", current floor:" + currentFloor + ", going to floor:" + addressedFloor + ", end destination:" + endFloor);
    }
    
}
